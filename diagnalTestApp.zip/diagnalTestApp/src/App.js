import React from 'react';
import './style/App.css';
import GridView from './components/gridView.component'
import Header from './components/Header.component';
import Footer from './components/Footer.component';
function App() {
 
  return (
    <div className="app container txt-center">
      <Header />  
         <GridView/>
      <Footer />
    </div>
  );
} 

export default App;
