

//note ->  not defined any action because we don't mention is attach file

const intialState={
    data:{}
}

const reducer=function(state, action){
    switch(action.type){
        case 'loadlist2':
            state = require('../../public/API/CONTENTLISTINGPAGE-PAGE2.json');
            return state;
        case 'loadlist3':
            state = require('../../public/API/CONTENTLISTINGPAGE-PAGE3.json');
            return state;
        default:
            state = require('../../public/API/CONTENTLISTINGPAGE-PAGE1.json');
            return state;
    }
};
export {reducer}