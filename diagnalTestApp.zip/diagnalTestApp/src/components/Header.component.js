import React from 'react';
import {connect} from 'react-redux';

const Header=function(props){
    return(<header className="header">
                <div className="back-btn"></div>
                    <div className="listing-title">{props.listInfo&&props.listInfo.title}</div>
                <div className="search-btn"></div>
        </header>);
}
const mapStateToProps=((state)=>{
    return{listInfo:state.page}
});
export default connect(mapStateToProps, null)(Header);