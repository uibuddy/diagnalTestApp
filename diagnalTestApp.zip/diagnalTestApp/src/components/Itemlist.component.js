
import React from 'react';
import {connect} from 'react-redux';
const itemList=function(props){
    const renderList=()=>{
        return props.listInfo['content-items'].content.map((item, i)=>{
                return (<li key={i}>
                    <figure>
                        <img src={'../../public/images/'+item['poster-image']}/>
                    </figure>
                    <div className="title">{item.name}</div>
                </li>) 
            });
    }
    
  return(<ul>{renderList()}</ul>);
}

const mapStateToProps=((state)=>{
    return{listInfo:state.page}
});
export default connect(mapStateToProps, null)(itemList);