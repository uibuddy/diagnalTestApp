import React, {Suspense } from 'react';
const gridView=function(){
    const LazyList = React.lazy(() => import('./Itemlist.component'));
    return(
        <div>
            <Suspense fallback={<div>List is loading... </div>}>
                <LazyList/>
            </Suspense>
        </div>
    )
}
export default gridView;