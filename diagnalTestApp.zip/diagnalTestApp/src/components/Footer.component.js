import React from 'react';

const Footer=function(props){
    return(<footer className="footer">
                <div className="text-center">Copyright 2021</div>
        </footer>);
}
export default Footer;