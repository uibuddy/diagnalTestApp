Please follow below steps to run this app:


1. download and Unzip app repo

2. inside current repo path run -- npm install

3. to run app -- npm run start

4. to test code coverage -- npm run test