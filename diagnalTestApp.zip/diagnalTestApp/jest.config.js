const path = require('path')

module.exports = {
  roots: [path.resolve(__dirname, './src')],
  testEnvironment: 'jest-environment-jsdom-sixteen',
  displayName: 'tests',
  testMatch: ['**//__tests__/**/*.js', '**/?(*.)+(spec|test).[jt]s?(x)'],
  moduleNameMapper: {
    '\\.(css|less)$': '<rootDir>/__mocks__/styleMock.js',
  }
}